# Huliot DU Calculation Web App

**EN 12056-2 Drainage Unit Calculator — Streamlit Cloud Edition**

Deploy once → access from mobile/desktop anywhere. No local Python or pip install needed.

---

## What It Does

| Feature | Details |
|---|---|
| Upload Excel | Accepts your `DU_Calculation_sheet.xlsx` |
| Auto-parse | Detects sections (Kitchen, Toilet, etc.) |
| Inline editing | Edit QTY and Floors directly in browser |
| Live calculation | Total DU → Flow (l/s) → Pipe Dia (mm) per EN 12056-2 |
| Download | Formatted .xlsx with 4 sheets: DU Summary, Project Report, Plumber Record, Builder BOQ |
| Mobile-friendly | Responsive layout, works on phone |

---

## ☁️ Deploy on Streamlit Cloud (FREE — Recommended)

### Step 1 — Push to GitHub
```bash
# Create a new repo on github.com, then:
git init
git add .
git commit -m "Huliot DU App"
git remote add origin https://github.com/YOUR_USERNAME/huliot-du-app.git
git push -u origin main
```

### Step 2 — Deploy on Streamlit Cloud
1. Go to **https://share.streamlit.io**
2. Sign in with GitHub
3. Click **"New app"**
4. Select your repo → branch: `main` → file: `app.py`
5. Click **Deploy** ✅

**Your app URL:**  
`https://YOUR_USERNAME-huliot-du-app-app-XXXXXX.streamlit.app`

Share this URL with your team — they open it in mobile browser, done.

---

## 🖥️ Run Locally (Optional)

```bash
pip install -r requirements.txt
streamlit run app.py
```

---

## Files

```
huliot-du-app/
├── app.py                  ← Main Streamlit application
├── requirements.txt        ← Python dependencies
├── .streamlit/
│   └── config.toml         ← Theme and upload size config
└── README.md               ← This file
```

---

## Calculation Method — EN 12056-2

| Formula | Description |
|---|---|
| `Total DU = QTY × DU × Floors` | Per fixture |
| `Q = K × √(ΣDU)` | Flow in l/s (K=0.7 default) |
| Pipe size from flow table | 110mm, 125mm, 160mm etc. |

**K Factor options:**
- `0.5` = Intermittent use (offices, daytime only)
- `0.7` = Frequent use (residential) ← default
- `1.0` = Congested use (hospitals, hotels with peak loads)

---

## Output Excel Sheets

| Sheet | Purpose |
|---|---|
| **DU Summary** | Colour-coded fixture table per section |
| **Project Report** | Grand totals, pipe recommendations |
| **Plumber Record** | Blank log for field team site entries |
| **Builder BOQ** | Pipe sizes per zone for procurement |

---

*Huliot Pipes & Fittings Pvt. Ltd. — West Zone Technical Team*
